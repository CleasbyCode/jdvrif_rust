#include "encryption.h"
#include "file_utils.h"
#include "recover.h"
#include "recover_modes.h"

#include <cstdio>
#include <stdexcept>
#include <string_view>

namespace {
fs::path recovery_image;
fs::path replacement_image;
bool twitter_called = false;
bool reddit_called = false;
std::size_t decoded_size = 0;
}

// Replace the file at the external key-derivation boundary, after recoverData
// has validated its original size. The recovery routing, opened-file read,
// metadata probes, and size checks use their production implementations.
std::uint64_t deriveCarrierKeyFromPinFile(std::span<const Byte>) {
    fs::rename(replacement_image, recovery_image);
    return 1;
}

std::optional<TwitterEncryptedEnvelope> extractTwitterEnvelope(
    std::span<const Byte> image, std::uint64_t) {
    twitter_called = true;
    decoded_size = image.size();
    return std::nullopt;
}

std::optional<RedditEncryptedEnvelope> extractRedditEnvelope(
    std::span<const Byte> image, std::uint64_t) {
    reddit_called = true;
    decoded_size = image.size();
    return std::nullopt;
}

void recoverFromIccPath(const fs::path&, std::size_t, std::size_t, vBytes&) {
    throw std::runtime_error("Unexpected ICC recovery route");
}
void recoverFromBlueskyPath(const fs::path&, std::size_t, std::size_t, vBytes&) {
    throw std::runtime_error("Unexpected Bluesky recovery route");
}
void recoverFromTwitterPath(TwitterEncryptedEnvelope, vBytes&) {
    throw std::runtime_error("Unexpected Twitter payload");
}
void recoverFromRedditPath(RedditEncryptedEnvelope, vBytes&) {
    throw std::runtime_error("Unexpected Reddit payload");
}

int main(int argc, char** argv) {
    if (argc < 4) return 2;
    const std::string_view mode = argv[1];
    if (mode == "read" || mode == "pin") {
        if (argc != 4) return 2;
        try {
            const auto type = mode == "pin" ? FileTypeCheck::pin_file : FileTypeCheck::embedded_image;
            const auto bytes = readFile(argv[2], type, std::stoull(argv[3]));
            std::printf("read %zu bytes\n", bytes.size());
            return 0;
        } catch (const std::exception& error) {
            std::fprintf(stderr, "%s\n", error.what());
            return 1;
        }
    }

    if (argc != 5 || (mode != "recover-limit" && mode != "recover-twitter" &&
                      mode != "recover-reddit")) return 2;
    recovery_image = argv[2];
    replacement_image = argv[3];
    const std::size_t expected_size = std::stoull(argv[4]);
    vBytes pin{'1', '\n'};
    try {
        recoverData(recovery_image, pin);
    } catch (const std::runtime_error& error) {
        const std::string_view message = error.what();
        if (mode == "recover-limit") {
            if (message.find("permitted size limit") != std::string_view::npos &&
                !twitter_called && !reddit_called) return 0;
        } else if (message.find("Invalid PIN") != std::string_view::npos &&
                   decoded_size == expected_size && reddit_called &&
                   twitter_called == (mode == "recover-twitter")) {
            return 0;
        }
        std::fprintf(stderr, "Unexpected recovery result: %s (Twitter=%d, Reddit=%d, bytes=%zu)\n",
                     error.what(), twitter_called, reddit_called, decoded_size);
    } catch (const std::exception& error) {
        std::fprintf(stderr, "Unexpected exception: %s\n", error.what());
    }
    return 1;
}
