#!/bin/bash
# X-Twitter adaptive format, carrier, recovery, and boundary tests.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
TESTS="$ROOT/tests"
FIXTURES="$TESTS/fixtures"
IN_BIN="${JDV_IN_BIN:-$ROOT/jdv_in}"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_twitter_tests.sh [options]

Options:
  --no-build        Reuse existing binaries.
  --in-bin <path>   Use an explicit jdv_in binary path.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

JDV_IN_BIN and JDV_OUT_BIN provide the same binary overrides.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --in-bin)
            [[ $# -ge 2 ]] || { echo "--in-bin requires a path" >&2; exit 2; }
            IN_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        --out-bin)
            [[ $# -ge 2 ]] || { echo "--out-bin requires a path" >&2; exit 2; }
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage
            exit 2
            ;;
    esac
done

need_cmd() {
    if ! command -v "$1" >/dev/null 2>&1; then
        echo "Missing required command: $1" >&2
        exit 1
    fi
}

need_cmd cmp
need_cmd find
need_cmd grep
need_cmd python3
need_cmd sed
need_cmd stat
need_cmd "${CXX:-g++}"

if [[ "$IN_BIN" != /* ]]; then IN_BIN="$(pwd -P)/${IN_BIN#./}"; fi
if [[ "$OUT_BIN" != /* ]]; then OUT_BIN="$(pwd -P)/${OUT_BIN#./}"; fi
if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_in.sh && bash ./compile_jdv_out.sh)
fi
for binary in "$IN_BIN" "$OUT_BIN"; do
    [[ -x "$binary" ]] || { echo "Binary not found or not executable: $binary" >&2; exit 1; }
done

COVER="$FIXTURES/covers/cover_default.jpg"
PAYLOAD="$FIXTURES/payloads/payload_text.txt"
LARGE_PAYLOAD="$FIXTURES/payloads/bsingle.bin"
for fixture in "$COVER" "$PAYLOAD" "$LARGE_PAYLOAD"; do
    [[ -f "$fixture" ]] || { echo "Missing test fixture: $fixture" >&2; exit 1; }
done

WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdvrif-twitter.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT
PASS=0

extract_embedded_image() {
    sed -n 's/.*Saved "file-embedded" JPG image: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

extract_pin() {
    sed -n 's/.*Recovery PIN: \[\*\*\*\([0-9][0-9]*\)\*\*\*\].*/\1/p' "$1" | tail -n 1
}

extract_recovered_file() {
    sed -n 's/.*Extracted hidden file: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

assert_no_output_image() {
    local dir="$1"
    if find "$dir" -maxdepth 1 -type f -name 'jrif_*.jpg' -print -quit | grep -q .; then
        echo "unexpected X-Twitter output image after failed conceal" >&2
        return 1
    fi
}

# The low-level carrier must round-trip arbitrary bytes under the same key and
# must not be locatable with another key. This validates the format primitive
# shared by the conceal and recovery routes.
"${CXX:-g++}" \
    -std=c++23 -O2 -DNDEBUG \
    -Wall -Wextra -Wpedantic -Wshadow -Wconversion \
    -I"$ROOT" \
    "$TESTS/test_twitter_carrier.cpp" \
    "$ROOT/twitter_steg.cpp" \
    "$ROOT/twitter_jpeg_codec.cpp" \
    "$ROOT/twitter_juniward.cpp" \
    "$ROOT/twitter_stc.cpp" \
    "$ROOT/signal_utils.cpp" \
    -ljpeg -lsodium \
    -o "$WORK/test_twitter_carrier"
"$WORK/test_twitter_carrier" "$COVER" "$PAYLOAD"
PASS=$((PASS + 1))

# Both web capacity routes must use the same in-memory carrier preparation as
# conceal, report envelope-aware limits, and save no output image.
mkdir "$WORK/capsize_twitter"
cp "$COVER" "$WORK/capsize_twitter/cover.jpg"
(
    cd "$WORK/capsize_twitter"
    "$IN_BIN" capsize -x cover.jpg > capsize.log 2>&1
)
grep -Fq 'X-Twitter capacity check for conceal -x mode only.' "$WORK/capsize_twitter/capsize.log"
grep -Eq '^Cover Image: [0-9]+KiB, 1280x960, Progressive YCbCr 4:2:0, Source-derived Q65 quantization \(J-UNIWARD/STC\)\.$' "$WORK/capsize_twitter/capsize.log"
grep -Eq '^Theoretical J-UNIWARD/STC capacity limit for this cover image: +739 bytes \(~0KiB\)\.$' "$WORK/capsize_twitter/capsize.log"
grep -Eq '^Conservative maximum compressed capacity with a 20-character filename: +625 bytes \(~0KiB\)\.$' "$WORK/capsize_twitter/capsize.log"
grep -Eq '^Recommended  maximum compressed capacity with a 20-character filename: +0 bytes \(~0KiB\)\.$' "$WORK/capsize_twitter/capsize.log"
grep -Fq 'consume 95 to 114 bytes' "$WORK/capsize_twitter/capsize.log"
grep -Fq 'must remain within 5MiB.' "$WORK/capsize_twitter/capsize.log"
assert_no_output_image "$WORK/capsize_twitter"
PASS=$((PASS + 1))

mkdir "$WORK/capsize_reddit"
cp "$COVER" "$WORK/capsize_reddit/cover.jpg"
(
    cd "$WORK/capsize_reddit"
    "$IN_BIN" capsize -r cover.jpg > capsize.log 2>&1
)
grep -Fq 'Reddit capacity check for conceal -r mode only.' "$WORK/capsize_reddit/capsize.log"
grep -Eq '^Cover Image: [0-9]+KiB, 1280x960, Baseline YCbCr 4:2:0, Standard Q75 quantization \(C3\)\.$' "$WORK/capsize_reddit/capsize.log"
grep -Eq '^Theoretical C3 capacity limit for this cover image: +8000 bytes \(~7KiB\)\.$' "$WORK/capsize_reddit/capsize.log"
grep -Eq '^Conservative maximum compressed capacity with a 20-character filename: +7886 bytes \(~7KiB\)\.$' "$WORK/capsize_reddit/capsize.log"
grep -Eq '^Recommended  maximum compressed capacity with a 20-character filename: +6862 bytes \(~6KiB\)\.$' "$WORK/capsize_reddit/capsize.log"
grep -Fq 'must remain within 20MiB.' "$WORK/capsize_reddit/capsize.log"
assert_no_output_image "$WORK/capsize_reddit"
PASS=$((PASS + 1))

# Successful CLI conceal and exact transport-format validation.
mkdir "$WORK/success"
cp "$COVER" "$WORK/success/cover.jpg"
cp "$PAYLOAD" "$WORK/success/payload.txt"
(
    cd "$WORK/success"
    "$IN_BIN" -x cover.jpg payload.txt > conceal.log 2>&1
)
OUTPUT_NAME="$(extract_embedded_image "$WORK/success/conceal.log")"
if [[ -z "$OUTPUT_NAME" || ! -f "$WORK/success/$OUTPUT_NAME" ]]; then
    echo "X-Twitter conceal did not report/create its output image" >&2
    exit 1
fi
grep -Fq 'X-Twitter. (Only share this "file-embedded" JPG image on X-Twitter).' "$WORK/success/conceal.log"
grep -Eq 'Recovery PIN: \[\*\*\*[0-9]+\*\*\*\]' "$WORK/success/conceal.log"
if grep -Fq 'X-Twitter carrier:' "$WORK/success/conceal.log"; then
    echo "successful X-Twitter conceal unexpectedly displayed capacity diagnostics" >&2
    exit 1
fi

python3 - "$WORK/success/$OUTPUT_NAME" "$WORK/success/cover.jpg" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
source_data = Path(sys.argv[2]).read_bytes()
jfif = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00"
if not data.startswith(jfif):
    raise SystemExit("X-Twitter output lacks the standard JFIF 1.01 header")
if len(data) > 5 * 1024 * 1024:
    raise SystemExit("X-Twitter output exceeds 5 MiB")

def parse_header(jpeg):
    tables = {}
    frame = None
    frame_marker = None
    apps = []
    comments = 0
    pos = 2
    while pos < len(jpeg):
        if jpeg[pos] != 0xFF:
            raise SystemExit(f"bad JPEG marker at {pos}")
        while pos < len(jpeg) and jpeg[pos] == 0xFF:
            pos += 1
        marker = jpeg[pos]
        pos += 1
        if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            continue
        length = int.from_bytes(jpeg[pos:pos + 2], "big")
        end = pos + length
        if length < 2 or end > len(jpeg):
            raise SystemExit("invalid JPEG segment length")
        payload = jpeg[pos + 2:end]
        if 0xE0 <= marker <= 0xEF:
            apps.append(marker)
        elif marker == 0xFE:
            comments += 1
        elif marker == 0xDB:
            cursor = 0
            while cursor < len(payload):
                spec = payload[cursor]
                cursor += 1
                precision, table_id = spec >> 4, spec & 0x0F
                table_bytes = 64 if precision == 0 else 128
                if precision > 1 or cursor + table_bytes > len(payload):
                    raise SystemExit("unexpected X-Twitter DQT encoding")
                tables[table_id] = (precision, payload[cursor:cursor + table_bytes])
                cursor += table_bytes
        elif marker in range(0xC0, 0xD0) and marker not in (0xC4, 0xC8, 0xCC):
            frame_marker = marker
            components = payload[5]
            values = []
            cursor = 6
            for _ in range(components):
                values.append((payload[cursor], payload[cursor + 1], payload[cursor + 2]))
                cursor += 3
            frame = values
        if marker == 0xDA:
            break
        pos = end
    return tables, frame, frame_marker, apps, comments

tables, frame, frame_marker, apps, comments = parse_header(data)
source_tables, source_frame, _, _, _ = parse_header(source_data)

if apps != [0xE0]:
    raise SystemExit(f"unexpected X-Twitter APP markers: {apps}")
if comments:
    raise SystemExit("X-Twitter output retained JPEG comments")
if frame_marker != 0xC2:
    raise SystemExit(f"X-Twitter output is not progressive SOF2 (ff{frame_marker:02x})")
if frame is None or [(entry[0], entry[1]) for entry in frame] != [
    (1, 0x22), (2, 0x11), (3, 0x11)
]:
    raise SystemExit(f"unexpected component/subsampling layout: {frame}")
if source_frame is None or len(source_frame) != 3:
    raise SystemExit("test source has an unexpected component layout")
for component in range(3):
    output_table = tables.get(frame[component][2])
    source_table = source_tables.get(source_frame[component][2])
    if output_table is None or output_table != source_table:
        raise SystemExit("X-Twitter output did not preserve source quantization tables")
PY
PASS=$((PASS + 1))

# Recover through the keyed progressive carrier, compact KDF envelope,
# authenticated secretstream decryptor, and streaming zlib inflater.
PIN="$(extract_pin "$WORK/success/conceal.log")"
if [[ -z "$PIN" ]]; then
    echo "X-Twitter conceal did not report a recovery PIN" >&2
    exit 1
fi
mkdir "$WORK/recover"
cp "$WORK/success/$OUTPUT_NAME" "$WORK/recover/embedded.jpg"
printf '%s\n' "$PIN" > "$WORK/recover/pin.txt"
chmod 600 "$WORK/recover/pin.txt"
(
    cd "$WORK/recover"
    "$OUT_BIN" embedded.jpg pin.txt > recover.log 2>&1
)
RECOVERED_NAME="$(extract_recovered_file "$WORK/recover/recover.log")"
if [[ -z "$RECOVERED_NAME" || ! -f "$WORK/recover/$RECOVERED_NAME" ]]; then
    echo "X-Twitter recovery did not report/create its decrypted output" >&2
    exit 1
fi
cmp "$PAYLOAD" "$WORK/recover/$RECOVERED_NAME"
grep -Fq 'Complete! Please check your file.' "$WORK/recover/recover.log"
PASS=$((PASS + 1))

# Recognized already-compressed types must bypass zlib at every size in both
# coefficient-carrier modes. Each fixture fits only in its raw form.
mkdir "$WORK/twitter_compressed_bypass"
cp "$COVER" "$WORK/twitter_compressed_bypass/cover.jpg"
python3 - "$WORK/twitter_compressed_bypass/payload.zip" <<'PY'
import hashlib
import sys
import zlib
from pathlib import Path

payload = b"".join(hashlib.sha256(i.to_bytes(4, "big")).digest() for i in range(20))[:630]
if len(zlib.compress(payload, 6)) <= 634:
    raise SystemExit("compressed-bypass fixture unexpectedly shrank enough to fit")
Path(sys.argv[1]).write_bytes(payload)
PY
(
    cd "$WORK/twitter_compressed_bypass"
    "$IN_BIN" -x cover.jpg payload.zip > conceal.log 2>&1
)
TW_BYPASS_OUTPUT="$(extract_embedded_image "$WORK/twitter_compressed_bypass/conceal.log")"
TW_BYPASS_PIN="$(extract_pin "$WORK/twitter_compressed_bypass/conceal.log")"
if [[ -z "$TW_BYPASS_OUTPUT" || -z "$TW_BYPASS_PIN" || ! -f "$WORK/twitter_compressed_bypass/$TW_BYPASS_OUTPUT" ]]; then
    echo "X-Twitter did not accept the below-10-MiB already-compressed payload without recompression" >&2
    exit 1
fi
mkdir "$WORK/twitter_compressed_bypass_recover"
cp "$WORK/twitter_compressed_bypass/$TW_BYPASS_OUTPUT" "$WORK/twitter_compressed_bypass_recover/embedded.jpg"
printf '%s\n' "$TW_BYPASS_PIN" > "$WORK/twitter_compressed_bypass_recover/pin.txt"
chmod 600 "$WORK/twitter_compressed_bypass_recover/pin.txt"
(
    cd "$WORK/twitter_compressed_bypass_recover"
    "$OUT_BIN" embedded.jpg pin.txt > recover.log 2>&1
)
TW_BYPASS_RECOVERED="$(extract_recovered_file "$WORK/twitter_compressed_bypass_recover/recover.log")"
if [[ -z "$TW_BYPASS_RECOVERED" || ! -f "$WORK/twitter_compressed_bypass_recover/$TW_BYPASS_RECOVERED" ]]; then
    echo "X-Twitter did not recover the uncompressed carrier payload" >&2
    exit 1
fi
cmp "$WORK/twitter_compressed_bypass/payload.zip" "$WORK/twitter_compressed_bypass_recover/$TW_BYPASS_RECOVERED"
PASS=$((PASS + 1))

mkdir "$WORK/reddit_compressed_bypass"
cp "$COVER" "$WORK/reddit_compressed_bypass/cover.jpg"
python3 - "$WORK/reddit_compressed_bypass/payload.zip" <<'PY'
import hashlib
import sys
import zlib
from pathlib import Path

payload = b"".join(hashlib.sha256(i.to_bytes(4, "big")).digest() for i in range(247))[:7890]
if len(zlib.compress(payload, 6)) <= 7895:
    raise SystemExit("compressed-bypass fixture unexpectedly shrank enough to fit")
Path(sys.argv[1]).write_bytes(payload)
PY
(
    cd "$WORK/reddit_compressed_bypass"
    "$IN_BIN" -r cover.jpg payload.zip > conceal.log 2>&1
)
RD_BYPASS_OUTPUT="$(extract_embedded_image "$WORK/reddit_compressed_bypass/conceal.log")"
RD_BYPASS_PIN="$(extract_pin "$WORK/reddit_compressed_bypass/conceal.log")"
if [[ -z "$RD_BYPASS_OUTPUT" || -z "$RD_BYPASS_PIN" || ! -f "$WORK/reddit_compressed_bypass/$RD_BYPASS_OUTPUT" ]]; then
    echo "Reddit did not accept the below-10-MiB already-compressed payload without recompression" >&2
    exit 1
fi
mkdir "$WORK/reddit_compressed_bypass_recover"
cp "$WORK/reddit_compressed_bypass/$RD_BYPASS_OUTPUT" "$WORK/reddit_compressed_bypass_recover/embedded.jpg"
printf '%s\n' "$RD_BYPASS_PIN" > "$WORK/reddit_compressed_bypass_recover/pin.txt"
chmod 600 "$WORK/reddit_compressed_bypass_recover/pin.txt"
(
    cd "$WORK/reddit_compressed_bypass_recover"
    "$OUT_BIN" embedded.jpg pin.txt > recover.log 2>&1
)
RD_BYPASS_RECOVERED="$(extract_recovered_file "$WORK/reddit_compressed_bypass_recover/recover.log")"
if [[ -z "$RD_BYPASS_RECOVERED" || ! -f "$WORK/reddit_compressed_bypass_recover/$RD_BYPASS_RECOVERED" ]]; then
    echo "Reddit did not recover the uncompressed carrier payload" >&2
    exit 1
fi
cmp "$WORK/reddit_compressed_bypass/payload.zip" "$WORK/reddit_compressed_bypass_recover/$RD_BYPASS_RECOVERED"
PASS=$((PASS + 1))

# Carrier position/key failure must not create plaintext, and must remain
# indistinguishable from a normal non-jdvrif progressive JPEG.
mkdir "$WORK/wrong_pin"
cp "$WORK/success/$OUTPUT_NAME" "$WORK/wrong_pin/embedded.jpg"
WRONG_PIN=1
if [[ "$PIN" == "$WRONG_PIN" ]]; then
    WRONG_PIN=2
fi
printf '%s\n' "$WRONG_PIN" > "$WORK/wrong_pin/pin.txt"
chmod 600 "$WORK/wrong_pin/pin.txt"
if (
    cd "$WORK/wrong_pin"
    "$OUT_BIN" embedded.jpg pin.txt > recover.log 2>&1
); then
    echo "X-Twitter recovery unexpectedly accepted a wrong PIN" >&2
    exit 1
fi
grep -Fq 'Invalid PIN, or this is not a valid jdvrif "file-embedded" image' "$WORK/wrong_pin/recover.log"
if find "$WORK/wrong_pin" -maxdepth 1 -type f -name 'payload*.txt' -print -quit | grep -q .; then
    echo "wrong-PIN X-Twitter recovery wrote plaintext" >&2
    exit 1
fi
PASS=$((PASS + 1))

# A compressed payload beyond the content-dependent capacity must fail before
# encryption and print the measured carrier diagnostics.
mkdir "$WORK/capacity"
cp "$COVER" "$WORK/capacity/cover.jpg"
cp "$LARGE_PAYLOAD" "$WORK/capacity/large.bin"
if (cd "$WORK/capacity" && "$IN_BIN" -x cover.jpg large.bin > conceal.log 2>&1); then
    echo "oversized compressed X-Twitter payload was unexpectedly accepted" >&2
    exit 1
fi
CAPACITY_COVER_BYTES="$(stat -c '%s' "$WORK/capacity/cover.jpg")"
CAPACITY_COVER_KIB="$((CAPACITY_COVER_BYTES / 1024))"
grep -Fq "Cover Image: ${CAPACITY_COVER_KIB}KiB, 1280x960, Progressive YCbCr 4:2:0, Source-derived Q65 quantization (J-UNIWARD/STC)." "$WORK/capacity/conceal.log"
grep -Eq '^Compressed data file \(payload\) size: [0-9]+ bytes \([0-9]+KiB\)\.$' "$WORK/capacity/conceal.log"
grep -Eq '^Theoretical J-UNIWARD/STC capacity limit for this cover image: +739 bytes \(~0KiB\)\.$' "$WORK/capacity/conceal.log"
grep -Eq '^Conservative maximum compressed capacity with a 20-character filename: +625 bytes \(~0KiB\)\.$' "$WORK/capacity/conceal.log"
grep -Eq '^Recommended  maximum compressed capacity with a 20-character filename: +0 bytes \(~0KiB\)\.$' "$WORK/capacity/conceal.log"
grep -Fq 'Data File Size Error:' "$WORK/capacity/conceal.log"
grep -Eq '^Already-compressed payload file size of [0-9]+ bytes \([0-9]+KiB\) exceeds the recommended maximum limit of 0 bytes \(~0KiB\) for this cover image\.$' "$WORK/capacity/conceal.log"
assert_no_output_image "$WORK/capacity"
PASS=$((PASS + 1))

# Cover and payload files each have an independent raw 5 MiB ceiling.
mkdir "$WORK/raw_payload"
cp "$COVER" "$WORK/raw_payload/cover.jpg"
cp "$PAYLOAD" "$WORK/raw_payload/payload.bin"
python3 - "$WORK/raw_payload/payload.bin" <<'PY'
import sys
with open(sys.argv[1], "r+b") as stream:
    stream.truncate(5 * 1024 * 1024 + 1)
PY
if (cd "$WORK/raw_payload" && "$IN_BIN" -x cover.jpg payload.bin > conceal.log 2>&1); then
    echo "over-5-MiB X-Twitter payload was unexpectedly accepted" >&2
    exit 1
fi
grep -Fq "Payload file exceeds X-Twitter's 5 MiB upload size limit" "$WORK/raw_payload/conceal.log"
assert_no_output_image "$WORK/raw_payload"
PASS=$((PASS + 1))

mkdir "$WORK/raw_cover"
cp "$COVER" "$WORK/raw_cover/cover.jpg"
cp "$PAYLOAD" "$WORK/raw_cover/payload.txt"
python3 - "$WORK/raw_cover/cover.jpg" <<'PY'
import sys
with open(sys.argv[1], "r+b") as stream:
    stream.truncate(5 * 1024 * 1024 + 1)
PY
if (cd "$WORK/raw_cover" && "$IN_BIN" -x cover.jpg payload.txt > conceal.log 2>&1); then
    echo "over-5-MiB X-Twitter cover was unexpectedly accepted" >&2
    exit 1
fi
grep -Fq "Cover image exceeds X-Twitter's 5 MiB upload size limit" "$WORK/raw_cover/conceal.log"
assert_no_output_image "$WORK/raw_cover"
PASS=$((PASS + 1))

# The 4096-pixel dimension check runs from the JPEG header before transcoding.
mkdir "$WORK/dimensions"
cp "$COVER" "$WORK/dimensions/cover.jpg"
cp "$PAYLOAD" "$WORK/dimensions/payload.txt"
python3 - "$WORK/dimensions/cover.jpg" <<'PY'
import sys
from pathlib import Path

path = Path(sys.argv[1])
data = bytearray(path.read_bytes())
pos = 2
while pos < len(data):
    if data[pos] != 0xFF:
        raise SystemExit("invalid JPEG while locating SOF")
    while pos < len(data) and data[pos] == 0xFF:
        pos += 1
    marker = data[pos]
    pos += 1
    if marker in (0x01, 0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
        continue
    length = int.from_bytes(data[pos:pos + 2], "big")
    if marker in range(0xC0, 0xD0) and marker not in (0xC4, 0xC8, 0xCC):
        data[pos + 5:pos + 7] = (4097).to_bytes(2, "big")
        path.write_bytes(data)
        break
    pos += length
else:
    raise SystemExit("SOF marker not found")
PY
if (cd "$WORK/dimensions" && "$IN_BIN" -x cover.jpg payload.txt > conceal.log 2>&1); then
    echo "over-4096-pixel X-Twitter cover was unexpectedly accepted" >&2
    exit 1
fi
grep -Fq "dimensions exceed X-Twitter's 4096x4096-pixel limit" "$WORK/dimensions/conceal.log"
assert_no_output_image "$WORK/dimensions"
PASS=$((PASS + 1))

echo "X-Twitter adaptive carrier tests passed: $PASS"
