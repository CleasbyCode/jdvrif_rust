#!/usr/bin/env bash
# Opened-input bounds and recovery replacement regressions for PIN-file tools.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdv-web-read-limits.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

# This helper deliberately uses a normal build: ASan's shadow mapping cannot
# start under the address-space cap used to prove rejection before allocation.
"${CXX:-g++}" -std=c++23 -O2 -Wall -Wextra -Wpedantic -Wshadow -Wconversion \
    -I"$ROOT" "$ROOT/tests/test_read_limits.cpp" "$ROOT/file_utils.cpp" \
    "$ROOT/recover.cpp" "$ROOT/recover_extract.cpp" "$ROOT/binary_io.cpp" \
    "$ROOT/base64.cpp" "$ROOT/signal_utils.cpp" -lsodium \
    -o "$WORK/test_read_limits"

python3 - "$WORK/test_read_limits" "$WORK" <<'PY'
import pathlib
import resource
import subprocess
import sys

helper, work_arg = sys.argv[1:]
work = pathlib.Path(work_arg)
MiB = 1024 * 1024


def limit_address_space():
    resource.setrlimit(resource.RLIMIT_AS, (128 * MiB,) * 2)


def sparse(path, size):
    with path.open("wb") as stream:
        stream.truncate(size)


def run(*arguments):
    return subprocess.run([helper, *map(str, arguments)], capture_output=True,
                          preexec_fn=limit_address_space, timeout=10)


small = work / "small.jpg"
small.write_bytes(bytes(range(32)))
result = run("read", small, 32)
assert result.returncode == 0 and b"read 32 bytes" in result.stdout, result
for maximum in (0, 31):
    result = run("read", small, maximum)
    assert result.returncode == 1 and b"permitted size limit" in result.stderr, result
large = work / "large.jpg"
sparse(large, 512 * MiB)
result = run("read", large, 20 * MiB)
assert result.returncode == 1 and b"permitted size limit" in result.stderr, result
print("[PASS] opened input accepts exact bounds and rejects before allocation")

pin = work / "pin.txt"
pin.write_bytes(b"1" * 64)
result = run("pin", pin, 128)
assert result.returncode == 0 and b"read 64 bytes" in result.stdout, result
result = run("pin", pin, 63)
assert result.returncode == 1 and b"permitted size limit" in result.stderr, result
pin.write_bytes(b"1" * 65)
result = run("pin", pin, 128)
assert result.returncode == 1 and b"64-byte size limit" in result.stderr, result
print("[PASS] PIN files retain their 64-byte type limit alongside caller limits")

for mode, original_size, new_size in (
    ("recover-limit", 1024, 512 * MiB),
    ("recover-twitter", 6 * MiB, 1024),
    ("recover-reddit", 1024, 6 * MiB),
):
    image = work / (mode + ".jpg")
    replacement = work / (mode + "-replacement.jpg")
    sparse(image, original_size)
    sparse(replacement, new_size)
    result = run(mode, image, replacement, new_size)
    assert result.returncode == 0, result
print("[PASS] recovery replacement enforces the cap and routes by opened-image size")
PY
