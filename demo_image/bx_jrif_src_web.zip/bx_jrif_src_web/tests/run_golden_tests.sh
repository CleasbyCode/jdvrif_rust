#!/bin/bash
# Recover the main project's KDF2 compatibility fixtures through jdv_out's
# file-based PIN interface.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
TESTS="$ROOT/tests"
FIXTURES="$TESTS/fixtures"
MANIFEST="$FIXTURES/golden/manifest.tsv"
OUT_BIN="${JDV_OUT_BIN:-$ROOT/jdv_out}"
NO_BUILD=0

usage() {
    cat <<'EOF'
Usage: tests/run_golden_tests.sh [options]

Options:
  --no-build        Reuse an existing jdv_out binary.
  --out-bin <path>  Use an explicit jdv_out binary path.
  -h, --help        Show this help.

The JDV_OUT_BIN environment variable provides the same binary override.
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --no-build)
            NO_BUILD=1
            shift
            ;;
        --out-bin)
            if [[ $# -lt 2 ]]; then
                echo "--out-bin requires a path" >&2
                exit 2
            fi
            OUT_BIN="$2"
            NO_BUILD=1
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ "$OUT_BIN" != /* ]]; then
    OUT_BIN="$(pwd -P)/${OUT_BIN#./}"
fi

if [[ "$NO_BUILD" -eq 0 ]]; then
    (cd "$ROOT" && bash ./compile_jdv_out.sh)
fi
if [[ ! -x "$OUT_BIN" ]]; then
    echo "jdv_out binary not found or not executable: $OUT_BIN" >&2
    exit 1
fi
if [[ ! -f "$MANIFEST" ]]; then
    echo "Missing golden manifest: $MANIFEST" >&2
    exit 1
fi

for command_name in cmp python3 sed stat; do
    if ! command -v "$command_name" >/dev/null 2>&1; then
        echo "Missing required command: $command_name" >&2
        exit 1
    fi
done

extract_recovered_file() {
    sed -n 's/.*Extracted hidden file: \(.*\) ([0-9][0-9]* bytes)\..*/\1/p' "$1" | tail -n 1
}

assert_legacy_kdf2_fixture() {
    python3 - "$1" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
if data.count(b"KDF2") != 1:
    raise SystemExit("fixture does not contain exactly one KDF2 marker")
if b"KDF3" in data or b"KDF4" in data:
    raise SystemExit("legacy fixture unexpectedly contains a newer KDF framing")
PY
}

assert_layout() {
    python3 - "$1" "$2" "$3" "$4" "$5" <<'PY'
import sys
from pathlib import Path

data = Path(sys.argv[1]).read_bytes()
option = sys.argv[2]
minimum_icc_segments = int(sys.argv[3])
expect_photoshop = int(sys.argv[4])
expect_xmp = int(sys.argv[5])

signature = bytes((0xB4, 0x6A, 0x3E, 0xEA, 0x5E, 0x9D, 0xF9))
if signature not in data:
    raise SystemExit("jdvrif signature not found")

if option == "-b":
    if (b"Photoshop 3.0" in data) != bool(expect_photoshop):
        raise SystemExit("unexpected Photoshop-segment state")
    if (b"<rdf:li" in data) != bool(expect_xmp):
        raise SystemExit("unexpected XMP-segment state")
else:
    mntr = data.find(b"mntrRGB")
    if mntr < 8:
        raise SystemExit("ICC signature not found")
    base = mntr - 8
    segment_count_offset = base + 0x2C8
    if segment_count_offset + 2 > len(data):
        raise SystemExit("ICC segment count is out of bounds")
    segment_count = int.from_bytes(
        data[segment_count_offset:segment_count_offset + 2], "big"
    )
    if segment_count < minimum_icc_segments:
        raise SystemExit(
            f"expected at least {minimum_icc_segments} ICC segments, got {segment_count}"
        )
PY
}

PASS=0
FAIL=0
WORK="$(mktemp -d "${TMPDIR:-/tmp}/jdv-web-golden.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT

run_case() {
    local case_id="$1"
    local option="$2"
    local payload_rel="$3"
    local golden_rel="$4"
    local pin="$5"
    local min_icc="$6"
    local expect_photoshop="$7"
    local expect_xmp="$8"
    local payload="$FIXTURES/${payload_rel#testdata/}"
    local image="$FIXTURES/$golden_rel"
    local case_dir="$WORK/$case_id"
    local recovered

    if [[ ! -f "$payload" || ! -f "$image" ]]; then
        echo "missing fixture for $case_id" >&2
        return 1
    fi
    # `|| return 1` is required, not decorative: run_case is invoked from an
    # `if`, which disables errexit for its whole body, so a bare assertion here
    # would have its failure silently discarded.
    assert_legacy_kdf2_fixture "$image" || return 1
    assert_layout "$image" "$option" "$min_icc" "$expect_photoshop" "$expect_xmp" || return 1

    mkdir -p "$case_dir"
    cp "$image" "$case_dir/input.jpg"
    printf '%s\n' "$pin" > "$case_dir/pin.txt"
    chmod 600 "$case_dir/pin.txt"

    if ! (cd "$case_dir" && "$OUT_BIN" input.jpg pin.txt > recover.log 2>&1); then
        echo "jdv_out failed for $case_id" >&2
        cat "$case_dir/recover.log" >&2
        return 1
    fi

    recovered="$(extract_recovered_file "$case_dir/recover.log")"
    if [[ -z "$recovered" || ! -f "$case_dir/$recovered" ]]; then
        echo "could not identify recovered output for $case_id" >&2
        cat "$case_dir/recover.log" >&2
        return 1
    fi
    if ! cmp -s "$case_dir/$recovered" "$payload"; then
        echo "recovered bytes differ for $case_id" >&2
        return 1
    fi
    if [[ "$(stat -c '%a' "$case_dir/$recovered")" != "600" ]]; then
        echo "recovered output is not mode 600 for $case_id" >&2
        return 1
    fi
}

while IFS=$'\t' read -r case_id option _cover_rel payload_rel golden_rel pin min_icc expect_photoshop expect_xmp; do
    [[ -z "$case_id" || "$case_id" == "case_id" ]] && continue
    if run_case "$case_id" "$option" "$payload_rel" "$golden_rel" "$pin" \
        "$min_icc" "$expect_photoshop" "$expect_xmp"; then
        echo "[PASS] $case_id"
        PASS=$((PASS + 1))
    else
        echo "[FAIL] $case_id" >&2
        FAIL=$((FAIL + 1))
    fi
done < "$MANIFEST"

echo
echo "KDF2 golden summary: PASS=$PASS FAIL=$FAIL"
echo "jdv_out: $OUT_BIN"
[[ "$FAIL" -eq 0 ]]
