# Split-interface regression tests

The fixtures and tests in this directory are self-contained. They verify both
web-variant executables rather than relying on the combined main-project CLI:

- `run_golden_tests.sh` recovers all five legacy KDF2 fixtures with PIN files.
- `run_roundtrip_tests.sh` creates and recovers fresh KDF4 default, Bluesky,
  and Reddit images, including the ICC, Photoshop, XMP, and metadata-free C3
  DCT-carrier paths.
- `run_twitter_tests.sh` verifies source-derived quantization in the progressive
  JFIF J-UNIWARD/STC carrier, both `jdv_in capsize` platform routes, exact
  split-binary recovery with a PIN file, wrong-PIN rejection, and X-Twitter's
  5 MiB and 4096x4096 input limits.
  The carrier unit test also checks full-capacity recovery after embedding
  reduces the nonzero coefficient count, and rejects oversized declared payloads.
- `run_security_smoke.sh` covers authenticated compression semantics, wrong and
  oversized PIN files, truncated ciphertext, fixed ICC layout enforcement,
  transactional PIN delivery, post-PIN commit failure leaving the durable
  image, the final Bluesky output limit, mode-specific
  JPEG quality, the default 4096x4096 ceiling, and transformation limits,
  signal cleanup, dangling symlink
  collisions, and the default recovery-cap wiggle room. Optional fixture
  generators are skipped when Pillow, FFmpeg, or ImageMagick is unavailable.
  It also runs the shared JPEG scan-limit, cancellation, codec-cleanup, and
  plaintext-wiping regressions, plus web-specific opened-file bounds and
  replacement tests. The web variant uses PIN files, so interactive terminal
  PIN tests from the combined CLI do not apply.

Legacy KDF2 recovery remains supported and prints an explicit warning about its
unauthenticated compression flag. The security suite checks that both intact
and altered legacy files produce the warning, while current KDF4 files do not.
Recovered legacy files should be checked against a trusted original.

Run the complete suite with:

```sh
bash tests/run_tests.sh
```

To test binaries built elsewhere:

```sh
bash tests/run_tests.sh --no-build \
  --in-bin /path/to/jdv_in \
  --out-bin /path/to/jdv_out
```

The same paths can be supplied through `JDV_IN_BIN` and `JDV_OUT_BIN`.
