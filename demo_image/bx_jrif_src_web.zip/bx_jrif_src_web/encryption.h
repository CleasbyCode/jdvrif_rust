#pragma once

#include "common.h"

#include <span>

enum class KdfMetadataVersion : Byte;

template<typename T>
struct SecureBuffer {
    T buf{};

    SecureBuffer() = default;

    ~SecureBuffer() {
        sodium_memzero(buf.data(), buf.size());
    }

    SecureBuffer(const SecureBuffer&) = delete;
    SecureBuffer& operator=(const SecureBuffer&) = delete;
    SecureBuffer(SecureBuffer&&) = delete;
    SecureBuffer& operator=(SecureBuffer&&) = delete;

    auto data() { return buf.data(); }
    auto size() const { return buf.size(); }
};

void buildBlueskySegments(vBytes& segment_vec, const vBytes& data_vec);

// Largest ciphertext buildBlueskySegments can actually pack (EXIF + two
// Photoshop datasets + the base64 XMP overflow), intersected with the program's
// Bluesky cap. Conceal checks the encrypted payload against this so an
// over-large one is refused up front instead of failing deep inside the packer;
// recovery enforces the same bound in validateBlueskyExifCapacity.
[[nodiscard]] std::size_t maxBlueskyEmbeddedCipherCapacity();

[[nodiscard]] std::size_t computeStreamEncryptedSizePrefixed(
    std::size_t input_plaintext_size,
    std::size_t prefix_plaintext_size);

[[nodiscard]] SecurePin encryptDataFileForBluesky(
    vBytes& segment_vec,
    const fs::path& data_path,
    std::size_t input_size,
    vString& platforms_vec,
    const std::string& data_filename,
    bool is_data_compressed);

[[nodiscard]] SecurePin encryptDataFileToFile(
    vBytes& segment_vec,
    const fs::path& data_path,
    std::size_t input_size,
    const std::string& data_filename,
    const fs::path& encrypted_output_path,
    bool is_data_compressed);

// Metadata-stripping carriers cannot preserve APP/ICC metadata, so return the
// 56-byte KDF block separately for their DCT-carried envelope. The legacy
// function name predates the X-Twitter carrier.
[[nodiscard]] SecurePin encryptDataFileForReddit(
    vBytes& kdf_metadata,
    const fs::path& data_path,
    std::size_t input_size,
    const std::string& data_filename,
    const fs::path& encrypted_output_path,
    bool is_data_compressed);

struct DecryptResult {
    std::string filename{};
    std::size_t output_size{0};
    bool failed{false};
};

// Validates KDF metadata (and Bluesky EXIF capacity), parses the recovery PIN
// file bytes, and derives the secretstream key + header. Intended to run before
// extracting ciphertext from the cover image so corrupt/oversized embeddings
// fail without multi-gigabyte staging I/O.
[[nodiscard]] KdfMetadataVersion prepareDecryptKeyFromMetadata(
    vBytes& metadata_vec,
    vBytes& pin_vec,
    bool isBlueskyFile,
    Key& out_key,
    StreamHeader& out_stream_header);

// Metadata-stripping coefficient carriers carry only the compact KDF block
// rather than an APP/EXIF template. Validates it, parses the supplied PIN-file
// bytes, and derives the same existing secretstream key/header pair.
// Carrier key derived from the PIN-file bytes without consuming the caller's
// buffer: recover needs the key to locate the carrier and still needs the
// buffer afterwards for the decrypt step. Works on a scrubbed private copy.
[[nodiscard]] std::uint64_t deriveCarrierKeyFromPinFile(std::span<const Byte> pin_data);

[[nodiscard]] KdfMetadataVersion prepareDecryptKeyFromKdfMetadata(
    std::span<const Byte> kdf_metadata,
    vBytes& pin_vec,
    Key& out_key,
    StreamHeader& out_stream_header);

// Streams encrypted_input_path through secretstream decrypt (and inflate when
// is_data_compressed) into stream_output_path using a key prepared above.
[[nodiscard]] DecryptResult decryptDataFileWithKey(
    const Key& key,
    const StreamHeader& stream_header,
    KdfMetadataVersion metadata_version,
    const fs::path& encrypted_input_path,
    const fs::path& stream_output_path,
    bool is_data_compressed);
