#include "encryption_stream_shared.h"
#include "file_utils.h"
#include "signal_utils.h"

#include <zlib.h>

#include <algorithm>
#include <cstring>
#include <format>
#include <fstream>
#include <limits>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>

namespace {
constexpr std::size_t STREAM_INFLATE_OUT_CHUNK_SIZE = 2 * 1024 * 1024;
constexpr std::size_t STREAM_INFLATE_MAX_OUTPUT = 3ULL * 1024 * 1024 * 1024;
constexpr const char* CORRUPT_FILENAME_ERROR = "File Extraction Error: Corrupt encrypted filename metadata.";

[[nodiscard]] uint32_t decodeFrameLength(std::span<const Byte, STREAM_FRAME_LEN_BYTES> frame_len_bytes) {
    return (static_cast<uint32_t>(frame_len_bytes[0]) << 24) |
           (static_cast<uint32_t>(frame_len_bytes[1]) << 16) |
           (static_cast<uint32_t>(frame_len_bytes[2]) << 8) |
           static_cast<uint32_t>(frame_len_bytes[3]);
}

template<typename ConsumeFn>
[[nodiscard]] bool pullSecretStreamFrame(
    crypto_secretstream_xchacha20poly1305_state& state,
    std::span<const Byte> cipher_frame,
    std::span<const Byte> associated_data,
    Byte* plain_dst,
    std::size_t plain_capacity,
    bool& has_final_tag,
    ConsumeFn&& consume) {

    constexpr std::size_t STREAM_ABYTES = crypto_secretstream_xchacha20poly1305_ABYTES;
    if (cipher_frame.size() < STREAM_ABYTES || cipher_frame.size() > plain_capacity + STREAM_ABYTES) return false;

    const std::size_t max_plain_chunk = cipher_frame.size() - STREAM_ABYTES;
    unsigned long long plain_size = 0;
    unsigned char tag = 0;

    const int pull_rc = crypto_secretstream_xchacha20poly1305_pull(
        &state, plain_dst, &plain_size, &tag,
        cipher_frame.data(), cipher_frame.size(),
        associated_data.data(), static_cast<unsigned long long>(associated_data.size()));
    if (pull_rc != 0 || plain_size > max_plain_chunk) return false;
    if (plain_size > 0) {
        consume(std::span<const Byte>(plain_dst, static_cast<std::size_t>(plain_size)));
    }

    has_final_tag = (tag == crypto_secretstream_xchacha20poly1305_TAG_FINAL);
    return true;
}

template<typename ConsumeFn>
[[nodiscard]] bool decryptWithSecretStreamFileInputChunks(
    const fs::path& encrypted_input_path,
    const Key& key,
    const StreamHeader& header,
    std::span<const Byte> associated_data,
    ConsumeFn&& consume) {

    std::ifstream input = openBinaryInputOrThrow(
        encrypted_input_path,
        "Read Error: Failed to open encrypted stream input.");

    (void)checkedFileSize(
        encrypted_input_path,
        "Read Error: Invalid encrypted stream input size.",
        true);

    SecretStreamStateGuard stream_state;
    if (crypto_secretstream_xchacha20poly1305_init_pull(&stream_state.state, header.data(), key.data()) != 0) {
        return false;
    }

    auto cipher_chunk = std::make_unique<CipherChunk>();
    auto plain_chunk = std::make_unique<PlainChunk>();
    ZeroGuard<CipherChunk> cipher_guard{cipher_chunk.get()};
    ZeroGuard<PlainChunk> plain_guard{plain_chunk.get()};

    bool has_final_tag = false;
    while (true) {
        throwIfSignalCancellationRequested();
        std::array<Byte, STREAM_FRAME_LEN_BYTES> frame_len_bytes{};
        if (!tryReadExact(input, frame_len_bytes.data(), frame_len_bytes.size())) return false;

        const uint32_t frame_len = decodeFrameLength(frame_len_bytes);
        if (frame_len > cipher_chunk->size() || !tryReadExact(input, cipher_chunk->data(), frame_len)) return false;
        if (!pullSecretStreamFrame(
                stream_state.state,
                std::span<const Byte>(cipher_chunk->data(), frame_len),
                associated_data,
                plain_chunk->data(),
                plain_chunk->size(),
                has_final_tag,
                consume)) {
            return false;
        }
        if (has_final_tag) break;
    }

    try {
        requireNoTrailingDataOrThrow(input, "Read Error: Invalid encrypted stream input size.");
    } catch (const std::exception&) {
        return false;
    }
    return true;
}

class StreamInflateToFile {
public:
    // output_path is a StagingFile (link-free inode reached through
    // /proc/self/fd): the inode already exists, so this truncates rather than
    // exclusively creating a new named file.
    explicit StreamInflateToFile(const fs::path& output_path)
        : output_(openBinaryOutputForStagingOrThrow(output_path)) {
        throwIf(inflateInit(&stream_) != Z_OK, "zlib: inflateInit failed");
        initialized_ = true;
    }

    StreamInflateToFile(const StreamInflateToFile&) = delete;
    StreamInflateToFile& operator=(const StreamInflateToFile&) = delete;

    ~StreamInflateToFile() {
        if (initialized_) inflateEnd(&stream_);
    }

    void consume(std::span<const Byte> compressed_chunk) {
        throwIfSignalCancellationRequested();
        if (compressed_chunk.empty()) return;
        throwIf(finished_, "zlib inflate error: trailing compressed data");
        throwIf(
            compressed_chunk.size() > static_cast<std::size_t>(std::numeric_limits<uInt>::max()),
            "zlib inflate error: compressed chunk exceeds supported size");

        stream_.next_in = const_cast<Byte*>(compressed_chunk.data());
        stream_.avail_in = static_cast<uInt>(compressed_chunk.size());

        while (stream_.avail_in > 0) {
            throwIfSignalCancellationRequested();
            stream_.next_out = out_chunk_.data();
            stream_.avail_out = static_cast<uInt>(out_chunk_.size());

            const int ret = inflate(&stream_, Z_NO_FLUSH);
            writeProduced(out_chunk_.size() - stream_.avail_out);

            if (ret == Z_STREAM_END) {
                finished_ = true;
                throwIf(stream_.avail_in != 0, "zlib inflate error: trailing compressed data");
                break;
            }
            if (ret == Z_BUF_ERROR) {
                throwIf(
                    stream_.avail_in > 0 && stream_.avail_out > 0,
                    "zlib inflate error: truncated or corrupt input");
                continue;
            }
            if (ret != Z_OK) throwInflateError(ret);
        }
    }

    [[nodiscard]] std::size_t finish() {
        while (!finished_) {
            throwIfSignalCancellationRequested();
            stream_.next_in = nullptr;
            stream_.avail_in = 0;
            stream_.next_out = out_chunk_.data();
            stream_.avail_out = static_cast<uInt>(out_chunk_.size());

            const int ret = inflate(&stream_, Z_FINISH);
            writeProduced(out_chunk_.size() - stream_.avail_out);

            if (ret == Z_STREAM_END) {
                finished_ = true;
                break;
            }
            if (ret == Z_BUF_ERROR) {
                if (stream_.avail_out == 0) continue;
                throw std::runtime_error("zlib inflate error: truncated or corrupt input");
            }
            if (ret != Z_OK) throwInflateError(ret);
        }

        closeOutputOrThrow(output_, WRITE_COMPLETE_ERROR);
        throwIf(output_size_ == 0, "Zlib Compression Error: Output file is empty. Inflating file failed.");
        return output_size_;
    }

private:
    [[noreturn]] void throwInflateError(int ret) const {
        throw std::runtime_error(std::format(
            "zlib inflate error: {}",
            stream_.msg ? stream_.msg : std::to_string(ret)));
    }

    void writeProduced(std::size_t produced) {
        if (produced == 0) return;
        throwIf(
            produced > STREAM_INFLATE_MAX_OUTPUT || output_size_ > STREAM_INFLATE_MAX_OUTPUT - produced,
            "zlib inflate error: output exceeds safe size limit");
        writeBytesOrThrow(output_, std::span<const Byte>(out_chunk_.data(), produced), WRITE_COMPLETE_ERROR);
        output_size_ += produced;
    }

    z_stream stream_{};
    bool initialized_{false};
    bool finished_{false};
    std::ofstream output_{};
    vBytes out_chunk_ = vBytes(STREAM_INFLATE_OUT_CHUNK_SIZE);
    // Recovered plaintext survives here even when a later frame fails to
    // authenticate. Wipe the entire allocation on every exit path.
    WipeBytesGuard out_chunk_wipe_{out_chunk_};
    std::size_t output_size_{0};
};

class FilenamePrefixExtractor {
public:
    FilenamePrefixExtractor() = default;
    FilenamePrefixExtractor(const FilenamePrefixExtractor&) = delete;
    FilenamePrefixExtractor& operator=(const FilenamePrefixExtractor&) = delete;

    ~FilenamePrefixExtractor() {
        if (!filename_.empty()) {
            sodium_memzero(filename_.data(), filename_.size());
        }
    }

    template<typename PayloadFn>
    void consume(std::span<const Byte> chunk, PayloadFn&& payload_consume) {
        std::size_t pos = 0;

        if (!has_length_) {
            if (chunk.empty()) return;
            expected_len_ = chunk[pos++];
            has_length_ = true;
            throwIf(expected_len_ == 0, CORRUPT_FILENAME_ERROR);
            filename_.reserve(expected_len_);
        }

        if (filename_.size() < expected_len_) {
            const std::size_t need = expected_len_ - filename_.size();
            const std::size_t take = std::min(need, chunk.size() - pos);
            if (take > 0) {
                filename_.append(
                    reinterpret_cast<const char*>(chunk.data() + static_cast<std::ptrdiff_t>(pos)),
                    take);
                pos += take;
            }
        }

        if (pos < chunk.size()) {
            payload_consume(chunk.subspan(pos));
        }
    }

    [[nodiscard]] bool isComplete() const noexcept { return has_length_ && filename_.size() == expected_len_; }
    [[nodiscard]] const std::string& filename() const noexcept { return filename_; }

private:
    bool has_length_{false};
    std::size_t expected_len_{0};
    std::string filename_{};
};

void appendOutputChunkToFile(std::ostream& output, std::span<const Byte> chunk, std::size_t& output_size) {
    throwIf(
        chunk.size() > std::numeric_limits<std::size_t>::max() - output_size,
        "File Size Error: Decrypted output size overflow.");
    writeBytesOrThrow(output, chunk, WRITE_COMPLETE_ERROR);
    output_size += chunk.size();
}

template<typename DecryptFn>
[[nodiscard]] bool decryptCompressedPayloadToFile(
    DecryptFn&& decrypt_fn,
    const fs::path& output_path,
    std::size_t& output_size,
    std::string& decrypted_filename) {

    FilenamePrefixExtractor prefix_extractor;
    StreamInflateToFile inflater(output_path);

    const bool ok = decrypt_fn([&](std::span<const Byte> chunk) {
        prefix_extractor.consume(chunk, [&](std::span<const Byte> payload) {
            inflater.consume(payload);
        });
    });
    if (!ok || !prefix_extractor.isComplete()) return false;

    output_size = inflater.finish();
    decrypted_filename = prefix_extractor.filename();
    return true;
}

template<typename DecryptFn>
[[nodiscard]] bool decryptPlainPayloadToFile(
    DecryptFn&& decrypt_fn,
    const fs::path& output_path,
    std::size_t& output_size,
    std::string& decrypted_filename) {

    FilenamePrefixExtractor prefix_extractor;
    // Same StagingFile inode as the compressed path above.
    std::ofstream output = openBinaryOutputForStagingOrThrow(output_path);

    const bool ok = decrypt_fn([&](std::span<const Byte> chunk) {
        prefix_extractor.consume(chunk, [&](std::span<const Byte> payload) {
            appendOutputChunkToFile(output, payload, output_size);
        });
    });
    if (!ok || !prefix_extractor.isComplete()) return false;

    closeOutputOrThrow(output, WRITE_COMPLETE_ERROR);
    decrypted_filename = prefix_extractor.filename();
    return true;
}

template<typename DecryptFn>
[[nodiscard]] bool decryptToFileExtractingFilenameImpl(
    DecryptFn&& decrypt_fn,
    bool is_compressed_payload,
    const fs::path& output_path,
    std::size_t& output_size,
    std::string& decrypted_filename) {

    output_size = 0;
    decrypted_filename.clear();

    if (is_compressed_payload) {
        return decryptCompressedPayloadToFile(
            std::forward<DecryptFn>(decrypt_fn),
            output_path,
            output_size,
            decrypted_filename);
    }

    return decryptPlainPayloadToFile(
        std::forward<DecryptFn>(decrypt_fn),
        output_path,
        output_size,
        decrypted_filename);
}
} // namespace

[[nodiscard]] bool decryptWithSecretStreamFileInputToFileExtractingFilename(
    const fs::path& encrypted_input_path,
    const Key& key,
    const StreamHeader& header,
    KdfMetadataVersion metadata_version,
    bool is_compressed_payload,
    const fs::path& output_path,
    std::size_t& output_size,
    std::string& decrypted_filename) {

    const std::array<Byte, 1> mode_data{streamModeByte(is_compressed_payload)};
    const std::span<const Byte> associated_data =
        authenticatesStreamMode(metadata_version)
            ? std::span<const Byte>(mode_data)
            : std::span<const Byte>{};

    return decryptToFileExtractingFilenameImpl(
        [&](auto&& consume) {
            return decryptWithSecretStreamFileInputChunks(
                encrypted_input_path,
                key,
                header,
                associated_data,
                consume);
        },
        is_compressed_payload,
        output_path,
        output_size,
        decrypted_filename);
}
