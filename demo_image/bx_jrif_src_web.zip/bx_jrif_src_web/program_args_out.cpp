#include "program_args_out.h"

#include <format>
#include <stdexcept>
#include <string>

namespace {
[[nodiscard]] std::string programName(int argc, char** argv) {
    if (argc <= 0 || argv[0] == nullptr) return "jdv_out";
    return fs::path(argv[0]).filename().string();
}

[[nodiscard]] std::string usageText(int argc, char** argv) {
    return std::format("Usage: {} <cover_image> <pin_file>", programName(argc, argv));
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
    const std::string usage = usageText(argc, argv);
    if (argc != 3) die(usage);

    ProgramArgs out;
    out.image_file_path = argv[1];
    out.pin_file_path = argv[2];
    return out;
}

[[noreturn]] void ProgramArgs::die(const std::string& message) {
    throw std::runtime_error(message);
}
