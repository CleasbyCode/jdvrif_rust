#include "program_args_in.h"

#include <format>
#include <stdexcept>
#include <string>
#include <string_view>

namespace {
[[nodiscard]] std::string_view argAt(int argc, char** argv, int index) {
    if (index < 0 || index >= argc || argv[index] == nullptr) return {};
    return argv[index];
}

[[nodiscard]] std::string programName(int argc, char** argv) {
    if (argc <= 0 || argv[0] == nullptr) return "jdv_in";
    return fs::path(argv[0]).filename().string();
}

[[nodiscard]] std::string usageText(int argc, char** argv) {
    constexpr std::string_view PREFIX = "Usage: ";
    const std::string prog = programName(argc, argv);
    const std::string indent(PREFIX.size(), ' ');
    return std::format(
        "{0}{1} [-b|-r|-x] <cover_image> <secret_file>\n"
        "{2}{1} capsize [-r|-x] <cover_image>",
        PREFIX,
        prog,
        indent);
}

[[nodiscard]] bool parseConcealOption(std::string_view arg, Option& option) {
    if (arg == "-b") {
        option = Option::Bluesky;
        return true;
    }
    if (arg == "-r") {
        option = Option::Reddit;
        return true;
    }
    if (arg == "-x") {
        option = Option::Twitter;
        return true;
    }
    return false;
}
} // namespace

ProgramArgs ProgramArgs::parse(int argc, char** argv) {
    const std::string usage = usageText(argc, argv);

    ProgramArgs out;

    if (argAt(argc, argv, 1) == "capsize") {
        int image_index = 2;
        out.mode = Mode::capsize;
        // Match the unified CLI: X-Twitter remains the default when the
        // capsize platform option is omitted.
        out.option = Option::Twitter;
        const std::string_view capsize_option = argAt(argc, argv, image_index);
        if (capsize_option == "-r") {
            out.option = Option::Reddit;
            ++image_index;
        } else if (capsize_option == "-x") {
            ++image_index;
        }

        if (argc != image_index + 1) die(usage);
        out.image_file_path = argAt(argc, argv, image_index);
        return out;
    }

    int image_index = 1;

    if (parseConcealOption(argAt(argc, argv, image_index), out.option)) {
        ++image_index;
    }

    if (argc != image_index + 2) die(usage);

    out.image_file_path = argAt(argc, argv, image_index);
    out.data_file_path = argAt(argc, argv, image_index + 1);
    return out;
}

[[noreturn]] void ProgramArgs::die(const std::string& message) {
    throw std::runtime_error(message);
}
